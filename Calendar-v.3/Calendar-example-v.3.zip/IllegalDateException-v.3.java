package calendar;

public class IllegalDateException extends Exception {

}
