package net.sf.eclipsecs.sample.filter;

public @interface ThreadSafe {

}
