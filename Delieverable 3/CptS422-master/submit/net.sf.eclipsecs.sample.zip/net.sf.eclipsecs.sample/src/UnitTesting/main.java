package UnitTesting;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double a = 0;
		a = 1 + 0;
	}

	public void A() {

	}

	public void B() {

	}

}
